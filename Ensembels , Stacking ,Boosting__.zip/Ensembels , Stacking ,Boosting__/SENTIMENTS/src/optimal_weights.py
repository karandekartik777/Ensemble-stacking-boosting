"""in this code file we try to find the optimal weights for out weighted average values 
   Which we can use to improve our model accuracy 
"""


import pandas as pd   
import glob
import numpy as np
from sklearn import metrics
from scipy import fmin


    

if __name__ == '__main__':

    files=glob.glob('../model_preds/*.csv')

    df=None
    for f in files:
        if df is None:
            df=pd.read_csv(f)
        else:
            temp_df=pd.read_csv(f)
            df=df.merge(temp_df,on='id',how='left')
    #print(df.head(10))

    targets=df.sentiment.values

    pred_cols=['lr_pred','lr_cnt_pred','rf_svd_pred']
